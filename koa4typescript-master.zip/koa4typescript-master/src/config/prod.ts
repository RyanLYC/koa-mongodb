const prodConfig = {
    baseUrl:'',
    baseHost:'',
    basePort:3025,
    baseSocketPort:8025,
    host_redis:'127.0.0.1',
    port_redis:6379,
    host_mongo:'127.0.0.1',
    port_mongo:27017,
    db_mongo:'test',
    user_mongo:'',
    password_mongo:'',
    useMongo:false
}

export default prodConfig